<?php $__env->startSection('title','Chi tiết sản phẩm'); ?>

<?php $__env->startSection('content'); ?>
    <div class="product-header">
        <h4><?php echo e($sanPham->ten); ?></h4>
    </div>
    <div class="product-media">
        <img src="<?php echo e($sanPham->anh_dai_dien); ?>" alt="anh_dai_dien" />
    </div>
    <div class="product-short-detail">
        <span>Giá: <?php echo e(number_format($sanPham->don_gia_ban)); ?> vnđ</span>
    </div>
    <div class="product-description">
        <h5>Mô tả:</h5>
        <p><?php echo e($sanPham->mo_ta); ?></p>
    </div>
    <div ng-controller="SanPhamController as vm">
        <textarea froala="vm.froalaOptions" ng-model="vm.myHtml"></textarea>
    </div>
    <scroll2top-btn></scroll2top-btn>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>