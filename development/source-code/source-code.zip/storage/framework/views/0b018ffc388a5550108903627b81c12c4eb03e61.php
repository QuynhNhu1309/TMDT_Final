<div class="product-list">
    <?php if(count($dsSanPham) > 0): ?>
        <?php $__currentLoopData = $dsSanPham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sanPham): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <div class="product-box">
                <div class="content">
                    <div class="inner-content product-image">
                        <img src="<?php echo e($sanPham->anh_dai_dien); ?>" alt="product-image" />
                    </div>
                    <div class="inner-content product-name">
                        <a href="<?php echo e(URL::route('sanpham.show', $sanPham->slug)); ?>"><?php echo e($sanPham->ten); ?></a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    <?php else: ?>
        <p>I don't have any records!</p>
    <?php endif; ?>
</div>