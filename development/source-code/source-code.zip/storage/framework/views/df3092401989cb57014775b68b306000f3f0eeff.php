<?php $__env->startSection('title','Laravel'); ?>

<?php $__env->startSection('sidebar'); ?>
    @parent
    <p>This is main page</p>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <button type="button" class="btn btn-danger">Confirm</button>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>