<?php $__env->startSection('title','Danh sách sản phẩm'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.category-sidebar', ['dsDanhMucSanPham' => $dsDanhMucSanPham], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->make('partials.product-list', ['dsSanPham' => $dsSanPham], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <scroll2top-btn></scroll2top-btn>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>