<?php $__env->startSection('title','Laravel'); ?>

<?php $__env->startSection('sidebar'); ?>
    @parent
    <p>List of javascript documents</p>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <ul>
        <li><a href="">Truthy/Falsy</a></li>
        <li><a href="">this</a></li>
        <li><a href="">Callback</a></li>
        <li><a href=""></a></li>
    </ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>