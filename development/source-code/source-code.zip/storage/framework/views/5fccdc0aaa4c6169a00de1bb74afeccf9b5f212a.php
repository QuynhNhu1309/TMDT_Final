<!-- Javascript Packages -->
<script type="text/javascript" src="<?php echo e(URL::asset('packages/jquery/jquery.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('packages/bootstrap/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('packages/angular/angular.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('packages/froala-editor/js/froala_editor.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('packages/angular-froala/src/angular-froala.js')); ?>"></script>


<!-- Angular App -->
<script type="text/javascript" src="<?php echo e(URL::asset('app/app.module.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('app/controllers/sanpham.controller.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('app/services/sanpham.service.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('app/directives/scroll2top-btn.directive.js')); ?>"></script>


<!-- Angular App -->
<script type="text/javascript" src="<?php echo e(URL::asset('app/app.module.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('app/controllers/sanpham.controller.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('app/services/sanpham.service.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('app/directives/scroll2top-btn.directive.js')); ?>"></script>
