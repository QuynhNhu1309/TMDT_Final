<?php $__env->startSection('title','Đăng nhập'); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-md-4 col-md-offset-4">
        <div class="panel panel-default">
            <div class="panel-heading"><strong>Login</strong></div>
            <div class="panel-body">
                <form id="formDangNhap" name="formDangNhap" action="<?php echo e(URL::Route('dangnhap.post')); ?>" method="POST" novalidate="novalidate" role="form">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="txtTenDangNhap">Tên đăng nhập </label>
                        <input class="form-control" type="text" id="txtTenDangNhap" name="txtTenDangNhap" maxlength="50" placeholder="Nhập tên đăng nhập"/>
                    </div>
                    <div class="form-group">
                        <label for="txtMatKhau">Mật khẩu </label>
                        <input class="form-control" type="password" id="txtMatKhau" name="txtMatKhau" maxlength="50" placeholder="Nhập mật khẩu" />
                    </div>
                    <div class="row">
                        <div class="col-md-4 col-md-offset-4 form-group">
                            <button class="btn btn-primary form-control" type="submit">Đăng nhập</button>
                        </div>
                    </div>
                    <div class="form-group">
                        <p class="text-center"><a href="<?php echo e(URL::Route('dangky.index')); ?>">Quên mật khẩu?</a></p>
                    </div>
                </form>
            </div>
        </div>
        <p class="text-center">Bạn không có tài khoản? <a href="<?php echo e(URL::Route('dangky.index')); ?>">Đăng ký tài khoản mới </a></p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>