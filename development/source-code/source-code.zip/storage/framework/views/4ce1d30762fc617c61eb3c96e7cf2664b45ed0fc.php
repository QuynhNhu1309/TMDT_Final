<div class="category-sidebar">
    <?php if(count($dsDanhMucSanPham) > 0): ?>
        <ul>
        <?php $__currentLoopData = $dsDanhMucSanPham; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $danhMucSanPham): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <li><a href="<?php echo e(URL::route('danhmuc.show', $danhMucSanPham->slug)); ?>"><?php echo e($danhMucSanPham->ten); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
    <?php endif; ?>
</div>